package geometry.diagram.edit.helpers;

/**
 * @generated
 */
public class GeometryEditHelper extends GeometryBaseEditHelper {
}
