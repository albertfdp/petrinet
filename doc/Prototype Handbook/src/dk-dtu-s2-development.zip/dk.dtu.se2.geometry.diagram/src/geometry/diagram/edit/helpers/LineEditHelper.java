package geometry.diagram.edit.helpers;

/**
 * @generated
 */
public class LineEditHelper extends GeometryBaseEditHelper {
}
