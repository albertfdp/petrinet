package geometry.diagram.preferences;

import geometry.diagram.part.GeometryDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(GeometryDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
