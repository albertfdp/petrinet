package geometry.diagram.providers;

import geometry.diagram.part.GeometryDiagramEditorPlugin;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	 * @generated
	 */
	public static ElementInitializers getInstance() {
		ElementInitializers cached = GeometryDiagramEditorPlugin.getInstance()
				.getElementInitializers();
		if (cached == null) {
			GeometryDiagramEditorPlugin.getInstance().setElementInitializers(
					cached = new ElementInitializers());
		}
		return cached;
	}
}
