package geometry.diagram.edit.helpers;

/**
 * @generated
 */
public class ConnectorEditHelper extends GeometryBaseEditHelper {
}
