package geometry.diagram.edit.helpers;

/**
 * @generated
 */
public class BendPointEditHelper extends GeometryBaseEditHelper {
}
