package geometry.diagram.edit.helpers;

/**
 * @generated
 */
public class InputPointEditHelper extends GeometryBaseEditHelper {
}
