package geometry.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class GeometryBaseEditHelper extends GeneratedEditHelperBase {

}
