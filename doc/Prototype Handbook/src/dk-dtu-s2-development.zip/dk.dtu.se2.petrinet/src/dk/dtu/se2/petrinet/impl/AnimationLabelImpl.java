/**
 */
package dk.dtu.se2.petrinet.impl;

import dk.dtu.se2.petrinet.AnimationLabel;
import dk.dtu.se2.petrinet.PetrinetPackage;

import org.eclipse.emf.ecore.EClass;

import org.pnml.tools.epnk.structuredpntypemodel.impl.StructuredLabelImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Animation Label</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class AnimationLabelImpl extends StructuredLabelImpl implements AnimationLabel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AnimationLabelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PetrinetPackage.Literals.ANIMATION_LABEL;
	}

} //AnimationLabelImpl
