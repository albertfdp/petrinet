/**
 */
package dk.dtu.se2.petrinet;

import org.pnml.tools.epnk.pnmlcoremodel.PetriNetType;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extended Petri Net</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.se2.petrinet.PetrinetPackage#getExtendedPetriNet()
 * @model
 * @generated
 */
public interface ExtendedPetriNet extends PetriNetType {
} // ExtendedPetriNet
