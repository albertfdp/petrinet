/**
 */
package dk.dtu.se2.petrinet;

import org.pnml.tools.epnk.structuredpntypemodel.StructuredLabel;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Animation Label</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.se2.petrinet.PetrinetPackage#getAnimationLabel()
 * @model
 * @generated
 */
public interface AnimationLabel extends StructuredLabel {
} // AnimationLabel
