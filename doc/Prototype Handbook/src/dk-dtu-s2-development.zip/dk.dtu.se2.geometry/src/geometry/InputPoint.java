/**
 */
package geometry;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see geometry.GeometryPackage#getInputPoint()
 * @model
 * @generated
 */
public interface InputPoint extends Point {
} // InputPoint
