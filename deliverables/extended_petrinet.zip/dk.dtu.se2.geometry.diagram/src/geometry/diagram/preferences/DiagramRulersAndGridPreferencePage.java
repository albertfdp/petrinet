package geometry.diagram.preferences;

import geometry.diagram.part.GeometryDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

// TODO: Auto-generated Javadoc
/**
 * The Class DiagramRulersAndGridPreferencePage.
 *
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * Instantiates a new diagram rulers and grid preference page.
	 *
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(GeometryDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
