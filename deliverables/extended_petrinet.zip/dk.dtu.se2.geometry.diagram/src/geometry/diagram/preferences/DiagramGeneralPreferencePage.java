package geometry.diagram.preferences;

import geometry.diagram.part.GeometryDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

// TODO: Auto-generated Javadoc
/**
 * The Class DiagramGeneralPreferencePage.
 *
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	 * Instantiates a new diagram general preference page.
	 *
	 * @generated
	 */
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(GeometryDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
