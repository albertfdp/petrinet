package geometry.diagram.part;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.gmf.tooling.runtime.actions.DefaultLoadResourceAction;

// TODO: Auto-generated Javadoc
/**
 * The Class LoadResourceAction.
 *
 * @generated
 */
public class LoadResourceAction extends DefaultLoadResourceAction {
	
	/**
	 * Execute.
	 *
	 * @param event the event
	 * @return the object
	 * @throws ExecutionException the execution exception
	 * @generated
	 */
	public Object execute(ExecutionEvent event) throws ExecutionException {
		return super.execute(event);
	}

}
