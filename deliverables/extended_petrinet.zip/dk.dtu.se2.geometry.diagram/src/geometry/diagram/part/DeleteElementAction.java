package geometry.diagram.part;

import org.eclipse.gmf.tooling.runtime.actions.DefaultDeleteElementAction;
import org.eclipse.ui.IWorkbenchPart;

// TODO: Auto-generated Javadoc
/**
 * The Class DeleteElementAction.
 *
 * @generated
 */
public class DeleteElementAction extends DefaultDeleteElementAction {

	/**
	 * Instantiates a new delete element action.
	 *
	 * @param part the part
	 * @generated
	 */
	public DeleteElementAction(IWorkbenchPart part) {
		super(part);
	}

}
