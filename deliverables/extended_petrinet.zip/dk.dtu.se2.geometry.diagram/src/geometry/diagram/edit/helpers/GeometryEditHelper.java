package geometry.diagram.edit.helpers;

/**
 * The Class GeometryEditHelper.
 *
 * @generated
 */
public class GeometryEditHelper extends GeometryBaseEditHelper {
}
