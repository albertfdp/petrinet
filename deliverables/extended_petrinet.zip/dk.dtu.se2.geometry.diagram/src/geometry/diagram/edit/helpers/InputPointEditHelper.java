package geometry.diagram.edit.helpers;

/**
 * The Class InputPointEditHelper.
 *
 * @generated
 */
public class InputPointEditHelper extends GeometryBaseEditHelper {
}
