package geometry.diagram.edit.helpers;

/**
 * The Class BendPointEditHelper.
 *
 * @generated
 */
public class BendPointEditHelper extends GeometryBaseEditHelper {
}
