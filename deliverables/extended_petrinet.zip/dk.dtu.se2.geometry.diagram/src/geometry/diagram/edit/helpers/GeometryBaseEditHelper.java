package geometry.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * The Class GeometryBaseEditHelper.
 *
 * @generated
 */
public class GeometryBaseEditHelper extends GeneratedEditHelperBase {

}
