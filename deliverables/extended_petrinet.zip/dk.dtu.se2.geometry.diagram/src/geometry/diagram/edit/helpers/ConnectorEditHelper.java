package geometry.diagram.edit.helpers;

/**
 * The Class ConnectorEditHelper.
 *
 * @generated
 */
public class ConnectorEditHelper extends GeometryBaseEditHelper {
}
