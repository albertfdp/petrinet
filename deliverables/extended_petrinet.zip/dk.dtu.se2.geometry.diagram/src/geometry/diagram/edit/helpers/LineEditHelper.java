package geometry.diagram.edit.helpers;

/**
 * The Class LineEditHelper.
 *
 * @generated
 */
public class LineEditHelper extends GeometryBaseEditHelper {
}
