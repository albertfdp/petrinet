/**
 */
package geometry;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bend Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see geometry.GeometryPackage#getBendPoint()
 * @model
 * @generated
 */
public interface BendPoint extends Point {
} // BendPoint
