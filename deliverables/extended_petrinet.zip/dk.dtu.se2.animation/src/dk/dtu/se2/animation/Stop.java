/**
 */
package dk.dtu.se2.animation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stop</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.se2.animation.AnimationPackage#getStop()
 * @model
 * @generated
 */
public interface Stop extends Animation {
} // Stop
