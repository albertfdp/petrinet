/**
 */
package dk.dtu.se2.animation;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Animation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.se2.animation.AnimationPackage#getAnimation()
 * @model
 * @generated
 */
public interface Animation extends EObject {
} // Animation
